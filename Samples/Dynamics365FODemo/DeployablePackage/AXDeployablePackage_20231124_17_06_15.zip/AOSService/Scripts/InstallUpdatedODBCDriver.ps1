Param([string]$logDir)

$OdbcTester = @"
using System;
using System.Runtime.InteropServices;

namespace UpdateOdbc
{
    public static class TestOdbcDriverManagerAPI
    {
        [DllImport("odbc32.dll", CharSet = CharSet.Unicode)]
        extern static short SQLAllocHandle(short HandleType, IntPtr InputHandle, out IntPtr OutputHandle);

        [DllImport("odbc32.dll")]
        private static extern short SQLFreeHandle(short hType, IntPtr handle);

        private const short SQL_SUCCESS = 0;
        private const short SQL_HANDLE_ENV = 1;

        public static bool TestAllocEnvHandle()
        {
            bool isSuccess = false;
            IntPtr henv = IntPtr.Zero;

            try
            {
                if ((SQL_SUCCESS == SQLAllocHandle(SQL_HANDLE_ENV, henv, out henv))
                    && (henv != IntPtr.Zero))
                {
                    isSuccess = true;
                }
            }
            catch (Exception)
            {
                isSuccess = false;
            }
            finally
            {
                if (henv != IntPtr.Zero)
                {
                    SQLFreeHandle(SQL_HANDLE_ENV, henv);
                }
            }

            return isSuccess;
        }
    }

    public static class TestOdbc17DriverAPI
    {
        [DllImport("msodbcsql17.dll", CharSet = CharSet.Unicode)]
        extern static short SQLAllocHandle(short HandleType, IntPtr InputHandle, out IntPtr OutputHandle);

        [DllImport("msodbcsql17.dll")]
        private static extern short SQLFreeHandle(short hType, IntPtr handle);

        private const short SQL_SUCCESS = 0;
        private const short SQL_HANDLE_ENV = 1;

        public static bool TestAllocEnvHandle()
        {
            bool isSuccess = false;
            IntPtr henv = IntPtr.Zero;

            try
            {
                if ((SQL_SUCCESS == SQLAllocHandle(SQL_HANDLE_ENV, henv, out henv))
                    && (henv != IntPtr.Zero))
                {
                    isSuccess = true;
                }
            }
            catch (Exception)
            {
                isSuccess = false;
            }
            finally
            {
                if (henv != IntPtr.Zero)
                {
                    SQLFreeHandle(SQL_HANDLE_ENV, henv);
                }
            }

            return isSuccess;
        }
    }
}
"@

$driverName = "ODBC Driver 13 for SQL Server"
$odbcMSIPath = Join-Path $PSScriptRoot "msodbcsql.msi"
$odbcMSIPath_v17 = Join-Path $PSScriptRoot "msodbcsql_17.msi"
$minimumVersion = New-Object System.Version("2015.131.4413.46")
$v171_Version = New-Object System.Version("2017.171.0.1")

if (Test-Path $odbcMSIPath_v17)
{
    $minimumVersion = New-Object System.Version("2017.172.0.1")
    $odbcMSIPath = $odbcMSIPath_v17
    $driverName = "ODBC Driver 17 for SQL Server"
}

$installDriver = $true
$unInstallDriver = $false
$driver = $null
if(Test-Path $odbcMSIPath)
{
  try
  {
      $driver = Get-ODBCDriver -Driver $driverName -Platform 64-bit -ErrorAction Stop
  }
  catch
  {
      $driver = $null
      Write-Output "Failed to get driver `"$driverName`""
  }

  if($driver)
  {
      $driverPath = $driver.Attribute["Driver"]
      $driverPath = [System.Environment]::ExpandEnvironmentVariables($driverPath)
      if(Test-Path $driverPath)
      {
          $driverVersionInfo = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($driverPath)
          $installedVersion = New-Object System.Version($driverVersionInfo.FileVersionRaw)
          Write-Output ("Found installed driver `"$driverName`" version `"$($installedVersion.ToString())`"")
          if ($installedVersion.CompareTo($v171_Version) -eq 0)
          {
              Write-Output ("Installed version of `"$($installedVersion.ToString())`", need to uninstall it and reinstall latest one.")

              $programName = "Microsoft ODBC Driver 17 for SQL Server"
              $app = Get-WmiObject -Class Win32_Product -Filter ("Name = '" + $programName + "'")

              # Uninstallation needs Admins
              if ($app)
              {
                  $uninstallRet = $app.Uninstall()
                  if($uninstallRet."ReturnValue" -ne 0)
                  {
                      throw "Failed to uninstall `"$($installedVersion.ToString())`". See for details"
                  }
              }

              $installDriver = $true
          }
          elseif ($installedVersion.CompareTo($minimumVersion) -ge 0)
          {
              if ($driverName -match "17")
              {
                  Write-Output "Installed version of `"$driverName`" validate runtime API"

                  $shortPath = Split-Path -Path $driverPath -Parent
                  $shortPath += "\1033\msodbcsqlr17.rll"
                  if (-Not(Test-Path $shortPath))
                  {
                      $installDriver = $true
                      $unInstallDriver = $true
                      Write-Output "Installed version of `"$driverName`" is not installed correctly. Need to reinstall it!"
                  }
                  else
                  {
                      Add-Type -TypeDefinition $OdbcTester -Language CSharp
                      $validateDriverManager = [UpdateOdbc.TestOdbcDriverManagerAPI]::TestAllocEnvHandle()
                      $validateDriver = [UpdateOdbc.TestOdbc17DriverAPI]::TestAllocEnvHandle()
                      if ($validateDriverManager -and $validateDriver)
                      {
                          $installDriver = $false
                          $unInstallDriver = $false
                          Write-Output "Installed version of `"$driverName`" validate runtime API successfully! Skipping install of updated driver."
                      }
                      else
                      {
                          $installDriver = $true
                          $unInstallDriver = $true
                          Write-Output "Installed version of `"$driverName`" is not installed correctly. API Test failed! Need to reinstall it."
                      }
                  }
              }
              else
              {
                  Write-Output ("Installed version of `"$driverName`" is greater or equal to the miniumum supported version `""+$minimumVersion.ToString() +"`". Skipping install of updated driver.")

                  $installDriver = $false
              }
          }
          else
          {
              Write-Output ("Installed version of `"$driverName`" is lower than miniumum supported version `""+$minimumVersion.ToString() +"`". Installing updated version...")
          }
      }
      else
      {
          Write-Output "Driver `"$driverName`" registered but the file was not found. Installing..."
      }
  }
  else
  {
    Write-Output "$driverName not found! Installing..."
  }

  if($installDriver)
  {
    # Initialize logs
    if (!$logdir -or $logdir -eq $null)
    {
        $logdir = $PSScriptRoot 
    }
    if ($unInstallDriver)
    {
        $odbcUninstallOutputLog = Join-Path $logdir "MSODBC_Uninstall.log"
        $msiExecArgs="/x `"$odbcMSIPath`" /quiet /passive /norestart /log `"$odbcUninstallOutputLog`" IACCEPTMSODBCSQLLICENSETERMS=YES"
        $msiExecProcess = Start-Process "msiexec.exe" $msiExecArgs -PassThru -Wait
        if($msiExecProcess.ExitCode -ne 0)
        {
            throw "Failed to uninstall `"$driverName`". See $odbcUninstallOutputLog for details"
        }
        else
        {
            Write-Output "Uninstall of `"$driverName`" completed successfully. Logs can be found at $odbcUninstallOutputLog"
        }
    }
    $odbcInstallOutputLog = Join-Path $logdir "MSODBC_Install.log"
    $msiExecArgs="/i `"$odbcMSIPath`" /quiet /passive /norestart /log `"$odbcInstallOutputLog`" IACCEPTMSODBCSQLLICENSETERMS=YES"
    $msiExecProcess = Start-Process "msiexec.exe" $msiExecArgs -PassThru -Wait
    if($msiExecProcess.ExitCode -ne 0)
    {
        throw "Failed to install `"$driverName`". See $odbcInstallOutputLog for details"
    }
    else
    {
        Write-Output "Install of `"$driverName`" completed successfully. Logs can be found at $odbcInstallOutputLog"
    }
  }
}
else
{
  Write-Output "Updated ODBC Driver MSI not found in package. No update required."
}
# SIG # Begin signature block
# MIIrfAYJKoZIhvcNAQcCoIIrbTCCK2kCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDVnUlPXG7oWgP0
# MWRNr8ubdOJ92Zybsm4Ybk4fFAIuhqCCEW4wggh+MIIHZqADAgECAhM2AAAByGSC
# ADC0I4J4AAIAAAHIMA0GCSqGSIb3DQEBCwUAMEExEzARBgoJkiaJk/IsZAEZFgNH
# QkwxEzARBgoJkiaJk/IsZAEZFgNBTUUxFTATBgNVBAMTDEFNRSBDUyBDQSAwMTAe
# Fw0yMzAzMjAyMDAwMzFaFw0yNDAzMTkyMDAwMzFaMCQxIjAgBgNVBAMTGU1pY3Jv
# c29mdCBBenVyZSBDb2RlIFNpZ24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
# AoIBAQCsqEftwg2QVZo09tbgIalDB+EPa9YjCbmINAgaNzlKKr0DL3IgHQw+9yRe
# enjTa759W/Lxlv5w9cLKJ6afIUbvBjAqA8Xj7HZrB3ht4eQW9xa1NX5jPmgQpVVP
# ShZHk1+xQe6oQYOUhUUBgH/sUiVlBZGILh6Z6Rr6NigVOXnRTaYND8K90Kq68B35
# 0FyGgfQEtdaHTSsrc2pGipCPnS9MeX4QHkcJ6vr64/uIUqJre8XDW4OicpUqZzPj
# HwYmjjLmnumVyvhUAHkV3BOlmvOEU5sHMnFzF0hPeoybTtFgzorURtSfcAopMQbY
# 7161DTqggoJwYeW2+PQ1mnfs2QQnAgMBAAGjggWKMIIFhjApBgkrBgEEAYI3FQoE
# HDAaMAwGCisGAQQBgjdbAQEwCgYIKwYBBQUHAwMwPQYJKwYBBAGCNxUHBDAwLgYm
# KwYBBAGCNxUIhpDjDYTVtHiE8Ys+hZvdFs6dEoFgg93NZoaUjDICAWQCAQwwggJ2
# BggrBgEFBQcBAQSCAmgwggJkMGIGCCsGAQUFBzAChlZodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpaW5mcmEvQ2VydHMvQlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1F
# JTIwQ1MlMjBDQSUyMDAxKDIpLmNydDBSBggrBgEFBQcwAoZGaHR0cDovL2NybDEu
# YW1lLmdibC9haWEvQlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1FJTIwQ1MlMjBDQSUy
# MDAxKDIpLmNydDBSBggrBgEFBQcwAoZGaHR0cDovL2NybDIuYW1lLmdibC9haWEv
# QlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1FJTIwQ1MlMjBDQSUyMDAxKDIpLmNydDBS
# BggrBgEFBQcwAoZGaHR0cDovL2NybDMuYW1lLmdibC9haWEvQlkyUEtJQ1NDQTAx
# LkFNRS5HQkxfQU1FJTIwQ1MlMjBDQSUyMDAxKDIpLmNydDBSBggrBgEFBQcwAoZG
# aHR0cDovL2NybDQuYW1lLmdibC9haWEvQlkyUEtJQ1NDQTAxLkFNRS5HQkxfQU1F
# JTIwQ1MlMjBDQSUyMDAxKDIpLmNydDCBrQYIKwYBBQUHMAKGgaBsZGFwOi8vL0NO
# PUFNRSUyMENTJTIwQ0ElMjAwMSxDTj1BSUEsQ049UHVibGljJTIwS2V5JTIwU2Vy
# dmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1BTUUsREM9R0JM
# P2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RDbGFzcz1jZXJ0aWZpY2F0aW9uQXV0
# aG9yaXR5MB0GA1UdDgQWBBSyQaGO0/lYIyoc4EhgSpg9HS8WQzAOBgNVHQ8BAf8E
# BAMCB4AwRQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEWMBQGA1UEBRMNMjM2MTY3KzUwMDM2MDCCAeYGA1UdHwSCAd0wggHZMIIB
# 1aCCAdGgggHNhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpaW5mcmEvQ1JM
# L0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5jcmyGMWh0dHA6Ly9jcmwxLmFtZS5nYmwv
# Y3JsL0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5jcmyGMWh0dHA6Ly9jcmwyLmFtZS5n
# YmwvY3JsL0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5jcmyGMWh0dHA6Ly9jcmwzLmFt
# ZS5nYmwvY3JsL0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5jcmyGMWh0dHA6Ly9jcmw0
# LmFtZS5nYmwvY3JsL0FNRSUyMENTJTIwQ0ElMjAwMSgyKS5jcmyGgb1sZGFwOi8v
# L0NOPUFNRSUyMENTJTIwQ0ElMjAwMSgyKSxDTj1CWTJQS0lDU0NBMDEsQ049Q0RQ
# LENOPVB1YmxpYyUyMEtleSUyMFNlcnZpY2VzLENOPVNlcnZpY2VzLENOPUNvbmZp
# Z3VyYXRpb24sREM9QU1FLERDPUdCTD9jZXJ0aWZpY2F0ZVJldm9jYXRpb25MaXN0
# P2Jhc2U/b2JqZWN0Q2xhc3M9Y1JMRGlzdHJpYnV0aW9uUG9pbnQwHwYDVR0jBBgw
# FoAUllGE4Gtve/7YBqvD8oXmKa5q+dQwHwYDVR0lBBgwFgYKKwYBBAGCN1sBAQYI
# KwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggEBAMbXnfc099nhsvSe5p709YIYfRmY
# 1yIJ6MyfvWv+KBMrHHrfkqZwjfyVhj++Fu776OEyU3dXcp4AkSa5R1tPG1peWGEn
# BZb/eLgZ9AaMUii3o3cX065dRF/yNzgvKlp2tYlXWXVuZn8bvkWKoygQMXsNiPJg
# n0E1RTdqU6BjJfKAEkmNJ8lH/xWB3yFgITGb0MmBcOVK4pntl4NqKU/YQYg7n6bR
# AYjW3Iwp1z9iA+slTDs0j3CbHwRP8nl/GuuHbV92jBigYJiemFi0aEYG+eoN1odd
# tUQILeDNtT6ct94UXfSuv+MfGhdbMp8VxgKPlefDnZu7mYNkHyMX90e+GU8wggjo
# MIIG0KADAgECAhMfAAAAUeqP9pxzDKg7AAAAAABRMA0GCSqGSIb3DQEBCwUAMDwx
# EzARBgoJkiaJk/IsZAEZFgNHQkwxEzARBgoJkiaJk/IsZAEZFgNBTUUxEDAOBgNV
# BAMTB2FtZXJvb3QwHhcNMjEwNTIxMTg0NDE0WhcNMjYwNTIxMTg1NDE0WjBBMRMw
# EQYKCZImiZPyLGQBGRYDR0JMMRMwEQYKCZImiZPyLGQBGRYDQU1FMRUwEwYDVQQD
# EwxBTUUgQ1MgQ0EgMDEwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDJ
# mlIJfQGejVbXKpcyFPoFSUllalrinfEV6JMc7i+bZDoL9rNHnHDGfJgeuRIYO1LY
# /1f4oMTrhXbSaYRCS5vGc8145WcTZG908bGDCWr4GFLc411WxA+Pv2rteAcz0eHM
# H36qTQ8L0o3XOb2n+x7KJFLokXV1s6pF/WlSXsUBXGaCIIWBXyEchv+sM9eKDsUO
# LdLTITHYJQNWkiryMSEbxqdQUTVZjEz6eLRLkofDAo8pXirIYOgM770CYOiZrcKH
# K7lYOVblx22pdNawY8Te6a2dfoCaWV1QUuazg5VHiC4p/6fksgEILptOKhx9c+ia
# piNhMrHsAYx9pUtppeaFAgMBAAGjggTcMIIE2DASBgkrBgEEAYI3FQEEBQIDAgAC
# MCMGCSsGAQQBgjcVAgQWBBQSaCRCIUfL1Gu+Mc8gpMALI38/RzAdBgNVHQ4EFgQU
# llGE4Gtve/7YBqvD8oXmKa5q+dQwggEEBgNVHSUEgfwwgfkGBysGAQUCAwUGCCsG
# AQUFBwMBBggrBgEFBQcDAgYKKwYBBAGCNxQCAQYJKwYBBAGCNxUGBgorBgEEAYI3
# CgMMBgkrBgEEAYI3FQYGCCsGAQUFBwMJBggrBgEFBQgCAgYKKwYBBAGCN0ABAQYL
# KwYBBAGCNwoDBAEGCisGAQQBgjcKAwQGCSsGAQQBgjcVBQYKKwYBBAGCNxQCAgYK
# KwYBBAGCNxQCAwYIKwYBBQUHAwMGCisGAQQBgjdbAQEGCisGAQQBgjdbAgEGCisG
# AQQBgjdbAwEGCisGAQQBgjdbBQEGCisGAQQBgjdbBAEGCisGAQQBgjdbBAIwGQYJ
# KwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMBIGA1UdEwEB/wQI
# MAYBAf8CAQAwHwYDVR0jBBgwFoAUKV5RXmSuNLnrrJwNp4x1AdEJCygwggFoBgNV
# HR8EggFfMIIBWzCCAVegggFToIIBT4YxaHR0cDovL2NybC5taWNyb3NvZnQuY29t
# L3BraWluZnJhL2NybC9hbWVyb290LmNybIYjaHR0cDovL2NybDIuYW1lLmdibC9j
# cmwvYW1lcm9vdC5jcmyGI2h0dHA6Ly9jcmwzLmFtZS5nYmwvY3JsL2FtZXJvb3Qu
# Y3JshiNodHRwOi8vY3JsMS5hbWUuZ2JsL2NybC9hbWVyb290LmNybIaBqmxkYXA6
# Ly8vQ049YW1lcm9vdCxDTj1BTUVSb290LENOPUNEUCxDTj1QdWJsaWMlMjBLZXkl
# MjBTZXJ2aWNlcyxDTj1TZXJ2aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPUFNRSxE
# Qz1HQkw/Y2VydGlmaWNhdGVSZXZvY2F0aW9uTGlzdD9iYXNlP29iamVjdENsYXNz
# PWNSTERpc3RyaWJ1dGlvblBvaW50MIIBqwYIKwYBBQUHAQEEggGdMIIBmTBHBggr
# BgEFBQcwAoY7aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraWluZnJhL2NlcnRz
# L0FNRVJvb3RfYW1lcm9vdC5jcnQwNwYIKwYBBQUHMAKGK2h0dHA6Ly9jcmwyLmFt
# ZS5nYmwvYWlhL0FNRVJvb3RfYW1lcm9vdC5jcnQwNwYIKwYBBQUHMAKGK2h0dHA6
# Ly9jcmwzLmFtZS5nYmwvYWlhL0FNRVJvb3RfYW1lcm9vdC5jcnQwNwYIKwYBBQUH
# MAKGK2h0dHA6Ly9jcmwxLmFtZS5nYmwvYWlhL0FNRVJvb3RfYW1lcm9vdC5jcnQw
# gaIGCCsGAQUFBzAChoGVbGRhcDovLy9DTj1hbWVyb290LENOPUFJQSxDTj1QdWJs
# aWMlMjBLZXklMjBTZXJ2aWNlcyxDTj1TZXJ2aWNlcyxDTj1Db25maWd1cmF0aW9u
# LERDPUFNRSxEQz1HQkw/Y0FDZXJ0aWZpY2F0ZT9iYXNlP29iamVjdENsYXNzPWNl
# cnRpZmljYXRpb25BdXRob3JpdHkwDQYJKoZIhvcNAQELBQADggIBAFAQI7dPD+jf
# XtGt3vJp2pyzA/HUu8hjKaRpM3opya5G3ocprRd7vdTHb8BDfRN+AD0YEmeDB5HK
# QoG6xHPI5TXuIi5sm/LeADbV3C2q0HQOygS/VT+m1W7a/752hMIn+L4ZuyxVeSBp
# fwf7oQ4YSZPh6+ngZvBHgfBaVz4O9/wcfw91QDZnTgK9zAh9yRKKls2bziPEnxeO
# ZMVNaxyV0v152PY2xjqIafIkUjK6vY9LtVFjJXenVUAmn3WCPWNFC1YTIIHw/mD2
# cTfPy7QA1pT+GPARAKt0bKtq9aCd/Ym0b5tPbpgCiRtzyb7fbNS1dE740re0COE6
# 7YV2wbeo2sXixzvLftH8L7s9xv9wV+G22qyKt6lmKLjFK1yMw4Ni5fMabcgmzRvS
# jAcbqgp3tk4a8emaaH0rz8MuuIP+yrxtREPXSqL/C5bzMzsikuDW9xH10graZzSm
# PjilzpRfRdu20/9UQmC7eVPZ4j1WNa1oqPHfzET3ChIzJ6Q9G3NPCB+7KwX0OQmK
# yv7IDimj8U/GlsHD1z+EF/fYMf8YXG15LamaOAohsw/ywO6SYSreVW+5Y0mzJutn
# BC9Cm9ozj1+/4kqksrlhZgR/CSxhFH3BTweH8gP2FEISRtShDZbuYymynY1un+Ry
# fiK9+iVTLdD1h/SxyxDpZMtimb4CgJQlMYIZZDCCGWACAQEwWDBBMRMwEQYKCZIm
# iZPyLGQBGRYDR0JMMRMwEQYKCZImiZPyLGQBGRYDQU1FMRUwEwYDVQQDEwxBTUUg
# Q1MgQ0EgMDECEzYAAAHIZIIAMLQjgngAAgAAAcgwDQYJYIZIAWUDBAIBBQCgga4w
# GQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisG
# AQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJ9OtWMQ3V6F3kSmxqBUebuEOAUwFY1u
# d27bi9+bSKXKMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8AcwBvAGYA
# dKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAEggEA
# dniu0+2+tsWOYJ2dvZt31bZk6+FnE1nuJCuATm4xdG670/Jp/dzzk4NHmqyOoM+H
# QpTaP7BsVVRbttDOWMv2MJnfq1dnFgwtBOz+ij/p4A1i83jJwYE1j9DmdANwTKCp
# gOopegsKYYKr9HCZA5+qCmPPJRGcmA6i6gEDtzH5qWhyvPOJg99HrbJld9u7ALSX
# z+kpkGL5gWbWDtx5zihPYmEkxzWuIxzeWgIdxfOBYm/Tro1M/d1z1BsgMkPULpWx
# S7yUnNREaYEgIZaTj0jdUMzBn4n8UTr+R0ROTqkGUtenxOKEXmz54QpKu6HSpMQX
# krQ3vDYfaOrojX5C85w1Y6GCFywwghcoBgorBgEEAYI3AwMBMYIXGDCCFxQGCSqG
# SIb3DQEHAqCCFwUwghcBAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFZBgsqhkiG9w0B
# CRABBKCCAUgEggFEMIIBQAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQCAQUA
# BCDLiJaWKXBBEq3g9UdWjOO5GnLSFW6UzCofaR7RI0RGvgIGZMmLS9NIGBMyMDIz
# MDgxMjAwNDQ1MS4xODJaMASAAgH0oIHYpIHVMIHSMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFuZCBP
# cGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjNCRDQt
# NEI4MC02OUMzMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# oIIRezCCBycwggUPoAMCAQICEzMAAAG0+4AIRAXSLfoAAQAAAbQwDQYJKoZIhvcN
# AQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjIwOTIwMjAy
# MjA5WhcNMjMxMjE0MjAyMjA5WjCB0jELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9u
# cyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjozQkQ0LTRCODAtNjlD
# MzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCAiIwDQYJ
# KoZIhvcNAQEBBQADggIPADCCAgoCggIBALRHpp5lBzJCH7zortuyvOmW8FoZLBsF
# e9g5dbhnaq9qSpvpn86E/mJ4JKvWixH/lw7QA8gPtiiGVNIjvFhu/XiY889vX5Wa
# QSmyoPMZdj9zvXa5XrkMN05zXzTePkCIIzF6RN7cTxezOyESymTIjrdxX5BVlZol
# yQAOxNziMCYKYYNPbYd0786fDE/PhzrRt23a0Xf8trvFa0LEEy2YlcE2eqg2CjU/
# D0GZe8Ra0kjt0M12vdS4qWZ2Dpd7IhiQwnntQWu19Ytd3UBR8SpeRX+Ccw3bjgWf
# OXtla6chctWt2shlMwayMOfY4TG4yMPWFXELfZFFp7cgpjZNeVsmwkvoV6RAwy1Y
# 9V+VvbJ5qFtartN/rp6a0I1kGlbjuwX3L0HTVXcikqgHistXk9h3HOZ9WgFXlxZu
# rG1SZmcz0BEEdya+1vGHE45KguYU9qq2LiHGBjn9z4+DqnV5tUKobsLbJMb4r+8s
# t2fj8SacSsftnusxkWqEJiJS34P2uNlzVR03+ls6+ZO0NcO79LgP7BbIMipiOx8y
# h19PMQw0piaKFwOW7Q+gdJcfy6rOkG+CrYZwOzdiBHSebIzCIch2cAa+38w7JFP/
# koKdlJ36qzdVXWv4G/qZpWycIvDKYbxJWM40+z2Stg5uHqK3I8e09kFXtxCHpS7h
# m8c8m25WaEU5AgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQUy0SF5fGUuDqcuxIot07e
# OMwy2X4wHwYDVR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYDVR0fBFgw
# VjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWlj
# cm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwGCCsGAQUF
# BwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3Br
# aW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgx
# KS5jcnQwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAOBgNV
# HQ8BAf8EBAMCB4AwDQYJKoZIhvcNAQELBQADggIBABLRDwWMKbeCYqEqtI6Bs8Km
# F+kqDR+2G6qYAK3ZZ63bert7pCkRJbihFaktl2o18cdFJFxnOF4vXadm0sabskJ0
# 5KviEMJIO6dXSq8AGtr3Zmjc895q0mnlBLuNMgk4R8KrkJMHqBuHqkUWXtfTrVUp
# gwzQt2UOiINKs+/b4r14MuXRVpOJ6cQOS8UhkeMAWl2iLlYaBGtOr3f/f9mLEPfW
# woke0sSUbdV60OZCRh1ItBYYM9efKr14H5qu6jan6n00prEEa7W3uGb/1/qj6P5e
# mnvkqy5HI0X69DjVdLxVbjSsegm/dA+S4DaXPcfFf6iBxK/iV21l1upgEVVajUAp
# l5VR40wY4XF8EpmnUdTqLXDf7CqdhDjPST2K/OjvWPyQGQvc7oPapYyk66GU32AO
# yyHXJj6+vbtRUg/+ory+h0R2Xf5NhC+xbWcMzXEUXRRf1YKZDsRyH6r412pm8KDK
# E/r7Rk7aoKK7oYUpNGzNRf6QaYv5z2bVTSxkzWivFrepLHGwvRun9PYM/8AQSTgZ
# r0yzzjk/97WghkqCaAwAVpyvg3uaYnuCl/AccSkGyb8c+70bFSeUephsfgb2r+QI
# 7Mb2WcOnkJpCNLz0XJMS/UwlQn1ktLsiCpsqOk3aLJ2wTv6LK3u69I0vQB/LKRKl
# ZYRXKUDXzoPwr3UtsTVTMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJmQAAAAAA
# FTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0
# aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1WjB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEBBQADggIP
# ADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjKNVf2AX9s
# SuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhgfWpSg0S3
# po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJprx2rrPY2
# vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/dvI2k45GP
# sjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka97aSueik3
# rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKRHh09/SDP
# c31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9ituqBJR6L8F
# A6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyOArxCaC4Q
# 6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItboKaDIV1f
# MHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6bMURHXLv
# jflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6tAgMBAAGj
# ggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBQqp1L+
# ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacbUzUZ6XIw
# XAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYzaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnkuaHRtMBMG
# A1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsG
# A1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJc
# YmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9z
# b2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIz
# LmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0
# MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/qXBS2Pk5H
# ZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6U03dmLq2
# HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVtI1TkeFN1
# JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis9/kpicO8
# F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTpkbKpW99J
# o3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0sHrYUP4K
# WN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138eW0QBjloZ
# kWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJsWkBRH58
# oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7Fx0ViY1w
# /ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0dFtq0Z4+
# 7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQtB1VM1iz
# oXBm8qGCAtcwggJAAgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3Bl
# cmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjozQkQ0LTRC
# ODAtNjlDMzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIj
# CgEBMAcGBSsOAwIaAxUAZZzYkPObl/ZzeCkSbf4B5CceCQiggYMwgYCkfjB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOiBN/Iw
# IhgPMjAyMzA4MTIwNjQyNThaGA8yMDIzMDgxMzA2NDI1OFowdzA9BgorBgEEAYRZ
# CgQBMS8wLTAKAgUA6IE38gIBADAKAgEAAgIUMQIB/zAHAgEAAgIR8jAKAgUA6IKJ
# cgIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6Eg
# oQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAFSJoXlEBULaBVf8F0lT/Ijk
# GDTuBV5EA0LyDMw3kQSjlixH1xGNCxClMta+ZiHR5C/4ZD6xm3Ms8IT8dPnXoom8
# Bp3+34yJ37r9L/6rOdSWO7yqfOewOeAyTUmSi3ahc/7x4bQYf6FcXCWDvauNp/Tn
# MpW01iYC00Cpt5wxeMsmMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgUENBIDIwMTACEzMAAAG0+4AIRAXSLfoAAQAAAbQwDQYJYIZIAWUDBAIBBQCg
# ggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQg
# UE1PlXYqXDONdtgkaeMb/aYXauRpWUVud24TL9DUdYowgfoGCyqGSIb3DQEJEAIv
# MYHqMIHnMIHkMIG9BCDTyPd75qMwcAZRcb36/6xJa3hT0eLse71ysdp4twH3BjCB
# mDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABtPuACEQF
# 0i36AAEAAAG0MCIEINLQeTNW1PNkNVYMM5YIPH2275LEYHdcpz9vn0PFUjhTMA0G
# CSqGSIb3DQEBCwUABIICABEE1n/senJHyRGJ/H57QWF+e5nrgK7cBgjWkVUJN3Vy
# zvOya0NcHpBUkDz18guRLMdDMGu/vR1wAJ7d931ePK1QK7OjxzOwrtwBe/k5sboM
# fjH1SetO77SDE7k2C1XyZ+OtTaM4Oa4o/gNbp+H/UWoVUjrlKf0XRA4FYO9tOt2q
# kJOYxFGvyORHky+pIchtE1EaBWasSPTG2an8UihYbCcLWHlkcnD7WZ6KzPUbAhyl
# VSNyNnJE/8cq7NUOsaCCYczmF4HbN1hzIuXekirDHMfLTILsidQ+0nwh52RBoXtS
# Za1yQ8IkFQCYy/xU5bepDuL6v/nzB/w9rcl9C0C1zlliv0ejcY2uQvqJ7us9+pQ0
# HRQUllUMMDA+VlE7NRiAQ5UAAaxK4TNSMiHgst5p2ucjgU+QFfNp04+MdxHV5mYk
# eVNfj36BdSDef0HGlV20npBmxlBpTWTT5WQyonsLJLVRXPngGotirBFzQSADLaNs
# nPydb3cFPrsXeruH3XoeaGnwIExVVigT//p60ok6f2F1w5DNZJxk2zEMr267Q2/U
# jzMUx5qxuTjl9hJeF/lQKeqDpSRiIgakSnOEMO8W45ubGb0c/XdVsStpVEBQmFqf
# NQCx/p/SpMRqRbTsDSag5Maev6HdRTJUFNg85zRItWI47zerp8n4xSm8M0pCBaTY
# SIG # End signature block
